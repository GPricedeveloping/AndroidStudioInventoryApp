package com.example.gpriceapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    EditText editNewUsername, editNewPassword;
    Button buttonRegister;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        editNewUsername = findViewById(R.id.editNewUsername);
        editNewPassword = findViewById(R.id.editNewPassword);
        buttonRegister = findViewById(R.id.buttonRegister);

        db = new DatabaseHelper(this);

        buttonRegister.setOnClickListener(v -> {
            String user = editNewUsername.getText().toString().trim();
            String pass = editNewPassword.getText().toString().trim();

            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                boolean success = db.insertUser(user, pass);
                if (success) {
                    Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(this, LoginActivity.class));
                    finish();
                } else {
                    Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
