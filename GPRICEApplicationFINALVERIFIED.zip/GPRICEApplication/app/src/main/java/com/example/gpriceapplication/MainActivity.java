package com.example.gpriceapplication;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText editItem;
    Button buttonAdd, buttonSendSMS;
    ListView listViewItems;
    ArrayList<String> itemList;
    ArrayAdapter<String> adapter;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editItem = findViewById(R.id.editItem);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonSendSMS = findViewById(R.id.buttonSendSMS);
        listViewItems = findViewById(R.id.listViewItems);

        db = new DatabaseHelper(this);
        itemList = db.getAllItems();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, itemList);
        listViewItems.setAdapter(adapter);

        buttonAdd.setOnClickListener(v -> {
            String item = editItem.getText().toString().trim();
            if (!item.isEmpty()) {
                db.insertItem(item);
                itemList.add(item);
                adapter.notifyDataSetChanged();
                editItem.setText("");
            } else {
                Toast.makeText(this, "Enter an item", Toast.LENGTH_SHORT).show();
            }
        });

        listViewItems.setOnItemClickListener((parent, view, position, id) -> {
            String selectedItem = itemList.get(position);
            showItemDialog(selectedItem, position);
        });

        buttonSendSMS.setOnClickListener(v ->
                SMSUtils.sendTestSMS(this, "5554", "This is a test message from GPRICEApp")
        );
    }

    private void showItemDialog(String item, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit or Delete Item");

        final EditText input = new EditText(this);
        input.setText(item);
        builder.setView(input);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String newItem = input.getText().toString().trim();
            if (!newItem.isEmpty()) {
                db.updateItem(item, newItem);
                itemList.set(position, newItem);
                adapter.notifyDataSetChanged();
                Toast.makeText(this, "Item updated", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Delete", (dialog, which) -> {
            db.deleteItem(item);
            itemList.remove(position);
            adapter.notifyDataSetChanged();
            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();
        });

        builder.setNeutralButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }
}
